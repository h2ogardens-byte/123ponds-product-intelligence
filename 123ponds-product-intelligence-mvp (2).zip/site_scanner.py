from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from collections import deque
from urllib.parse import urljoin, urlparse

import pandas as pd
import requests
from bs4 import BeautifulSoup

HEADERS = {"User-Agent": "123PondsProductIntelligence/1.0 (+public site audit)"}

def _get(url: str, timeout: int = 15):
    return requests.get(url, timeout=timeout, headers=HEADERS, allow_redirects=True)

def _sitemap_urls(url: str, limit: int) -> list[str]:
    candidates = []
    if url.lower().endswith(".xml"):
        candidates.append(url)
    else:
        candidates.extend([
            url.rstrip("/") + "/sitemap.xml",
            url.rstrip("/") + "/sitemap_index.xml",
        ])
    found = []
    seen_maps = set()
    queue = deque(candidates)
    while queue and len(found) < limit:
        sitemap = queue.popleft()
        if sitemap in seen_maps:
            continue
        seen_maps.add(sitemap)
        try:
            response = _get(sitemap)
            if response.status_code != 200 or "<loc>" not in response.text:
                continue
            root = ET.fromstring(response.content)
            locs = [node.text.strip() for node in root.iter() if node.tag.endswith("loc") and node.text]
            for loc in locs:
                if loc.lower().endswith(".xml"):
                    queue.append(loc)
                elif loc not in found:
                    found.append(loc)
                    if len(found) >= limit:
                        break
        except Exception:
            continue
    return found

def _crawl_links(base_url: str, limit: int) -> list[str]:
    try:
        response = _get(base_url)
        soup = BeautifulSoup(response.text, "lxml")
    except Exception:
        return []
    domain = urlparse(base_url).netloc
    urls = []
    for anchor in soup.select("a[href]"):
        href = urljoin(base_url, anchor.get("href", ""))
        parsed = urlparse(href)
        if parsed.netloc != domain or parsed.scheme not in {"http", "https"}:
            continue
        clean = href.split("#")[0]
        if clean not in urls:
            urls.append(clean)
        if len(urls) >= limit:
            break
    return urls

def _score(title_len, desc_len, h1_count, image_count, schema, words, status):
    score = 0
    if status == 200: score += 15
    if 25 <= title_len <= 65: score += 20
    elif title_len > 0: score += 10
    if 80 <= desc_len <= 170: score += 20
    elif desc_len > 0: score += 10
    if h1_count == 1: score += 15
    elif h1_count > 0: score += 8
    if image_count > 0: score += 10
    if schema: score += 10
    if words >= 250: score += 10
    elif words >= 100: score += 5
    return min(score, 100)

def scan_site(base_url: str, limit: int = 30) -> pd.DataFrame:
    urls = _sitemap_urls(base_url, limit)
    if not urls:
        urls = _crawl_links(base_url, limit)
    rows = []
    for url in urls[:limit]:
        try:
            response = _get(url)
            status = response.status_code
            soup = BeautifulSoup(response.text, "lxml")
            title = soup.title.get_text(" ", strip=True) if soup.title else ""
            meta = soup.select_one('meta[name="description"]')
            description = meta.get("content", "").strip() if meta else ""
            h1_count = len(soup.select("h1"))
            image_count = len(soup.select("img"))
            text = soup.get_text(" ", strip=True)
            word_count = len(re.findall(r"\b\w+\b", text))
            schema_text = " ".join(x.get_text(" ", strip=True) for x in soup.select('script[type="application/ld+json"]'))
            has_product_schema = '"Product"' in schema_text or "'Product'" in schema_text
            page_score = _score(
                len(title), len(description), h1_count, image_count,
                has_product_schema, word_count, status
            )
            rows.append({
                "url": url,
                "status": status,
                "title": title,
                "title_length": len(title),
                "description_length": len(description),
                "h1_count": h1_count,
                "image_count": image_count,
                "word_count": word_count,
                "product_schema": has_product_schema,
                "page_score": page_score,
            })
        except Exception as exc:
            rows.append({
                "url": url, "status": 0, "title": "", "title_length": 0,
                "description_length": 0, "h1_count": 0, "image_count": 0,
                "word_count": 0, "product_schema": False, "page_score": 0,
            })
    return pd.DataFrame(rows)
