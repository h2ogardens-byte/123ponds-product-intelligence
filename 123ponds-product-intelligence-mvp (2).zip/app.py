from __future__ import annotations

import io
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

from product_engine import (
    analyze_products,
    detect_columns,
    read_product_file,
    sample_products,
)
from site_scanner import scan_site

st.set_page_config(
    page_title="123Ponds Product Intelligence",
    page_icon="💧",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
[data-testid="stAppViewContainer"] {
    background: radial-gradient(circle at 12% 0%, #122847 0%, #08111f 38%, #050a12 100%);
    color: #f7fafc;
}
[data-testid="stSidebar"] {
    background: #08111f;
    border-right: 1px solid rgba(255,255,255,.08);
}
.block-container {padding-top: 1.3rem; padding-bottom: 2rem;}
.metric-card {
    background: linear-gradient(145deg, rgba(24,52,83,.95), rgba(10,23,39,.95));
    border: 1px solid rgba(111,194,255,.18);
    border-radius: 16px;
    padding: 18px 20px;
    min-height: 118px;
    box-shadow: 0 12px 28px rgba(0,0,0,.24);
}
.metric-label {font-size: .78rem; color: #9db4ca; text-transform: uppercase; letter-spacing: .08em;}
.metric-value {font-size: 2rem; font-weight: 750; margin-top: 4px;}
.metric-note {font-size: .78rem; color: #7f98ae; margin-top: 4px;}
.brand-title {font-size: 2.2rem; font-weight: 800; margin-bottom: 0;}
.brand-subtitle {color:#9db4ca; margin-top: 0;}
.status-pill {
    display:inline-block; padding:5px 10px; border-radius:999px;
    background:#123f35; color:#86efc3; font-size:.78rem; border:1px solid #246553;
}
div[data-testid="stDataFrame"] {border: 1px solid rgba(255,255,255,.08); border-radius: 12px;}
</style>
""", unsafe_allow_html=True)

def metric_card(label: str, value: str, note: str) -> None:
    st.markdown(
        f"""<div class="metric-card">
        <div class="metric-label">{label}</div>
        <div class="metric-value">{value}</div>
        <div class="metric-note">{note}</div>
        </div>""",
        unsafe_allow_html=True,
    )

@st.cache_data(show_spinner=False)
def cached_scan(base_url: str, limit: int) -> pd.DataFrame:
    return scan_site(base_url, limit=limit)

st.sidebar.markdown("## 123Ponds Intelligence")
st.sidebar.caption("Product profitability • shipping practicality • site coverage")
source = st.sidebar.radio("Data source", ["Use sample data", "Upload vendor file"])
uploaded = None
if source == "Upload vendor file":
    uploaded = st.sidebar.file_uploader("CSV or Excel", type=["csv", "xlsx", "xls"])

amazon_fee_pct = st.sidebar.slider("Amazon referral fee", 5.0, 25.0, 15.0, 0.5) / 100
payment_fee_pct = st.sidebar.slider("Website payment fee", 0.0, 6.0, 3.0, 0.25) / 100
shipping_default = st.sidebar.number_input("Default parcel shipping cost", 0.0, 100.0, 9.50, 0.50)
min_profit = st.sidebar.number_input("Minimum opportunity profit", 0.0, 500.0, 20.0, 5.0)

if uploaded is not None:
    raw = read_product_file(uploaded)
else:
    raw = sample_products()

mapping = detect_columns(raw.columns)
analyzed = analyze_products(
    raw,
    mapping=mapping,
    amazon_fee_pct=amazon_fee_pct,
    payment_fee_pct=payment_fee_pct,
    default_shipping=shipping_default,
)

st.markdown('<div class="status-pill">● MVP LIVE</div>', unsafe_allow_html=True)
st.markdown('<p class="brand-title">123Ponds Product Intelligence</p>', unsafe_allow_html=True)
st.markdown(
    '<p class="brand-subtitle">Find profitable, parcel-friendly products and identify catalog gaps before committing inventory.</p>',
    unsafe_allow_html=True,
)

tabs = st.tabs(["Executive Dashboard", "Product Explorer", "Website Scanner", "Import Mapping"])

with tabs[0]:
    parcel = analyzed[analyzed["shipping_class"] == "Parcel"]
    amazon_opps = parcel[parcel["amazon_profit"] >= min_profit]
    web_opps = parcel[parcel["website_profit"] >= min_profit]

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        metric_card("Products analyzed", f"{len(analyzed):,}", "Rows successfully normalized")
    with c2:
        metric_card("Parcel candidates", f"{len(parcel):,}", "Excludes obvious freight/oversize items")
    with c3:
        metric_card("Amazon opportunities", f"{len(amazon_opps):,}", f"Estimated profit ≥ ${min_profit:,.0f}")
    with c4:
        metric_card("Website opportunities", f"{len(web_opps):,}", f"Estimated profit ≥ ${min_profit:,.0f}")

    st.write("")
    left, right = st.columns([1.15, 1])
    with left:
        vendor_summary = (
            analyzed.groupby("vendor", dropna=False)
            .agg(
                products=("sku", "count"),
                parcel_candidates=("shipping_class", lambda x: (x == "Parcel").sum()),
                avg_website_profit=("website_profit", "mean"),
                avg_amazon_profit=("amazon_profit", "mean"),
            )
            .reset_index()
            .sort_values("avg_website_profit", ascending=False)
        )
        fig = px.bar(
            vendor_summary.head(12),
            x="vendor",
            y="avg_website_profit",
            title="Average Estimated Website Profit by Vendor",
        )
        fig.update_layout(
            template="plotly_dark",
            margin=dict(l=10, r=10, t=55, b=10),
            height=400,
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
        )
        st.plotly_chart(fig, use_container_width=True)

    with right:
        ship_counts = analyzed["shipping_class"].value_counts().rename_axis("class").reset_index(name="products")
        fig = px.pie(ship_counts, names="class", values="products", hole=.64, title="Shipping Practicality")
        fig.update_layout(
            template="plotly_dark",
            margin=dict(l=10, r=10, t=55, b=10),
            height=400,
            paper_bgcolor="rgba(0,0,0,0)",
        )
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Highest-priority parcel opportunities")
    opportunity_cols = [
        "opportunity_score", "vendor", "sku", "description", "cost", "sell_price",
        "shipping_class", "website_profit", "amazon_profit", "margin_pct",
    ]
    st.dataframe(
        analyzed.sort_values("opportunity_score", ascending=False)[opportunity_cols].head(30),
        use_container_width=True,
        hide_index=True,
        column_config={
            "cost": st.column_config.NumberColumn(format="$%.2f"),
            "sell_price": st.column_config.NumberColumn(format="$%.2f"),
            "website_profit": st.column_config.NumberColumn(format="$%.2f"),
            "amazon_profit": st.column_config.NumberColumn(format="$%.2f"),
            "margin_pct": st.column_config.NumberColumn(format="%.1f%%"),
            "opportunity_score": st.column_config.ProgressColumn(min_value=0, max_value=100),
        },
    )

with tabs[1]:
    f1, f2, f3, f4 = st.columns([1.5, 1, 1, 1])
    with f1:
        query = st.text_input("Search SKU, UPC, vendor, or description")
    with f2:
        ship_filter = st.multiselect(
            "Shipping class",
            options=sorted(analyzed["shipping_class"].dropna().unique()),
            default=sorted(analyzed["shipping_class"].dropna().unique()),
        )
    with f3:
        vendor_filter = st.multiselect(
            "Vendor",
            options=sorted(analyzed["vendor"].dropna().unique()),
        )
    with f4:
        minimum_profit = st.number_input("Min website profit", value=0.0, step=5.0)

    filtered = analyzed.copy()
    if query:
        mask = (
            filtered[["sku", "upc", "vendor", "description"]]
            .astype(str)
            .apply(lambda col: col.str.contains(query, case=False, na=False))
            .any(axis=1)
        )
        filtered = filtered[mask]
    filtered = filtered[filtered["shipping_class"].isin(ship_filter)]
    if vendor_filter:
        filtered = filtered[filtered["vendor"].isin(vendor_filter)]
    filtered = filtered[filtered["website_profit"] >= minimum_profit]

    st.caption(f"{len(filtered):,} matching products")
    st.dataframe(
        filtered,
        use_container_width=True,
        hide_index=True,
        height=560,
        column_config={
            "cost": st.column_config.NumberColumn(format="$%.2f"),
            "sell_price": st.column_config.NumberColumn(format="$%.2f"),
            "shipping_estimate": st.column_config.NumberColumn(format="$%.2f"),
            "website_profit": st.column_config.NumberColumn(format="$%.2f"),
            "amazon_profit": st.column_config.NumberColumn(format="$%.2f"),
            "margin_pct": st.column_config.NumberColumn(format="%.1f%%"),
            "opportunity_score": st.column_config.ProgressColumn(min_value=0, max_value=100),
        },
    )
    csv = filtered.to_csv(index=False).encode("utf-8")
    st.download_button("Download filtered CSV", csv, "123ponds-opportunities.csv", "text/csv")

with tabs[2]:
    st.write("Scan public 123Ponds pages for titles, descriptions, images, product schema, and basic page quality.")
    s1, s2, s3 = st.columns([2, 1, 1])
    with s1:
        base_url = st.text_input("Website or sitemap URL", "https://www.123ponds.com")
    with s2:
        scan_limit = st.number_input("Page limit", min_value=5, max_value=300, value=30, step=5)
    with s3:
        st.write("")
        st.write("")
        scan_clicked = st.button("Run scan", type="primary", use_container_width=True)

    if scan_clicked:
        with st.spinner("Scanning public pages…"):
            result = cached_scan(base_url, int(scan_limit))
        if result.empty:
            st.warning("No pages were found. Try entering a direct sitemap URL.")
        else:
            a, b, c, d = st.columns(4)
            with a:
                metric_card("Pages scanned", f"{len(result):,}", "Public URLs reviewed")
            with b:
                metric_card("Missing titles", f"{(result['title_length'] == 0).sum():,}", "Needs SEO attention")
            with c:
                metric_card("Missing descriptions", f"{(result['description_length'] == 0).sum():,}", "Search snippet opportunity")
            with d:
                metric_card("Weak page score", f"{(result['page_score'] < 60).sum():,}", "Score below 60/100")
            st.dataframe(
                result.sort_values("page_score"),
                use_container_width=True,
                hide_index=True,
                height=520,
                column_config={
                    "url": st.column_config.LinkColumn(),
                    "page_score": st.column_config.ProgressColumn(min_value=0, max_value=100),
                },
            )

with tabs[3]:
    st.subheader("Detected import mapping")
    st.json(mapping)
    st.write("Raw preview")
    st.dataframe(raw.head(25), use_container_width=True, hide_index=True)
    st.info(
        "The importer uses flexible column detection. For production, each vendor will get a saved mapping profile "
        "so future files can be processed automatically."
    )
