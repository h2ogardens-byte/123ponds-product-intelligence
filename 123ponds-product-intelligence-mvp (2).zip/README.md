# 123Ponds Product Intelligence

A working browser-based MVP for evaluating vendor products, parcel versus freight practicality, estimated website and Amazon contribution profit, and basic 123Ponds page quality.

## What it does

- Imports CSV and Excel vendor files
- Detects common SKU, UPC, vendor, cost, price, weight, dimension, and shipping columns
- Classifies products as Parcel, Large Parcel, or Freight / Oversize
- Estimates website and Amazon profit after shipping and fees
- Assigns an opportunity score
- Provides an executive dashboard, filters, search, charts, and CSV export
- Scans public website/sitemap URLs for basic SEO and product-page quality

## Run locally

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

Install and run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Render

1. Push these files to GitHub.
2. In Render, select **New → Blueprint**.
3. Connect this repository.
4. Render will read `render.yaml`.
5. Click deploy.

The app starts with sample product data, so it works before any vendor file is uploaded.

## Required vendor data

The importer is flexible, but the best files include:

- Vendor or manufacturer
- SKU or item number
- UPC
- Description
- Cost
- MAP, MSRP, retail, or selling price
- Weight
- Length, width, and height
- Shipping cost when available

## Current limitations

This MVP uses configurable estimates rather than live UPS, Amazon SP-API, Google Merchant Center, or Turbify data. Those integrations are the next production phase.
