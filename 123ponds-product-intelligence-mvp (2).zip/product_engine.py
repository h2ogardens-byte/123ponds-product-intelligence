from __future__ import annotations

import io
import math
import re
from typing import BinaryIO

import pandas as pd

ALIASES = {
    "sku": ["sku", "item number", "item no", "item", "part number", "part no", "model", "product id"],
    "upc": ["upc", "upc code", "barcode", "ean", "gtin"],
    "vendor": ["vendor", "manufacturer", "brand", "supplier", "mfg"],
    "description": ["description", "product description", "item description", "name", "title"],
    "cost": ["cost", "dealer cost", "wholesale", "unit cost", "price cost", "net cost"],
    "sell_price": ["sell price", "retail", "map", "msrp", "list price", "price"],
    "weight": ["weight", "ship weight", "shipping weight", "lbs", "weight lbs"],
    "length": ["length", "len", "ship length"],
    "width": ["width", "wid", "ship width"],
    "height": ["height", "ht", "ship height"],
    "shipping": ["shipping", "freight", "ship cost", "shipping cost"],
}

def _clean(value: object) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value).lower()).strip()

def detect_columns(columns) -> dict[str, str | None]:
    normalized = {_clean(c): str(c) for c in columns}
    mapping: dict[str, str | None] = {}
    for target, aliases in ALIASES.items():
        found = None
        for alias in aliases:
            a = _clean(alias)
            if a in normalized:
                found = normalized[a]
                break
        if found is None:
            for norm, original in normalized.items():
                if any(_clean(alias) in norm for alias in aliases):
                    found = original
                    break
        mapping[target] = found
    return mapping

def read_product_file(uploaded) -> pd.DataFrame:
    name = getattr(uploaded, "name", "").lower()
    if name.endswith(".csv"):
        try:
            return pd.read_csv(uploaded)
        except UnicodeDecodeError:
            uploaded.seek(0)
            return pd.read_csv(uploaded, encoding="latin-1")
    return pd.read_excel(uploaded)

def _numeric(series: pd.Series, default: float = 0.0) -> pd.Series:
    cleaned = (
        series.astype(str)
        .str.replace(r"[$,%]", "", regex=True)
        .str.replace(",", "", regex=False)
        .str.extract(r"(-?\d+(?:\.\d+)?)", expand=False)
    )
    return pd.to_numeric(cleaned, errors="coerce").fillna(default)

def _text(df: pd.DataFrame, column: str | None, default: str = "") -> pd.Series:
    if column and column in df:
        return df[column].fillna(default).astype(str).str.strip()
    return pd.Series([default] * len(df), index=df.index, dtype="object")

def _num(df: pd.DataFrame, column: str | None, default: float = 0.0) -> pd.Series:
    if column and column in df:
        return _numeric(df[column], default)
    return pd.Series([default] * len(df), index=df.index, dtype="float64")

def classify_shipping(weight, length, width, height, description):
    text = str(description).lower()
    freight_words = (
        "roll", "liner roll", "underlayment roll", "pallet", "freight",
        "truck", "bulk", "crate", "48 inch", "60 inch", "72 inch",
    )
    if any(word in text for word in freight_words):
        return "Freight / Oversize"
    dims = sorted([max(length, 0), max(width, 0), max(height, 0)], reverse=True)
    length_plus_girth = dims[0] + 2 * (dims[1] + dims[2])
    if weight > 70 or dims[0] > 48 or length_plus_girth > 130:
        return "Freight / Oversize"
    if weight > 25 or dims[0] > 30:
        return "Large Parcel"
    return "Parcel"

def analyze_products(
    raw: pd.DataFrame,
    mapping: dict[str, str | None],
    amazon_fee_pct: float = 0.15,
    payment_fee_pct: float = 0.03,
    default_shipping: float = 9.50,
) -> pd.DataFrame:
    df = pd.DataFrame(index=raw.index)
    df["vendor"] = _text(raw, mapping.get("vendor"), "Unknown")
    df["sku"] = _text(raw, mapping.get("sku"), "")
    df["upc"] = _text(raw, mapping.get("upc"), "")
    df["description"] = _text(raw, mapping.get("description"), "")
    df["cost"] = _num(raw, mapping.get("cost"))
    df["sell_price"] = _num(raw, mapping.get("sell_price"))
    df["weight"] = _num(raw, mapping.get("weight"))
    df["length"] = _num(raw, mapping.get("length"))
    df["width"] = _num(raw, mapping.get("width"))
    df["height"] = _num(raw, mapping.get("height"))
    entered_shipping = _num(raw, mapping.get("shipping"), default_shipping)
    entered_shipping = entered_shipping.mask(entered_shipping <= 0, default_shipping)

    df["shipping_class"] = [
        classify_shipping(w, l, wi, h, d)
        for w, l, wi, h, d in zip(
            df["weight"], df["length"], df["width"], df["height"], df["description"]
        )
    ]
    multiplier = df["shipping_class"].map({
        "Parcel": 1.0,
        "Large Parcel": 1.8,
        "Freight / Oversize": 12.0,
    }).fillna(1.0)
    df["shipping_estimate"] = (entered_shipping * multiplier).round(2)
    df["website_fees"] = (df["sell_price"] * payment_fee_pct).round(2)
    df["amazon_fees"] = (df["sell_price"] * amazon_fee_pct).round(2)
    df["website_profit"] = (
        df["sell_price"] - df["cost"] - df["shipping_estimate"] - df["website_fees"]
    ).round(2)
    df["amazon_profit"] = (
        df["sell_price"] - df["cost"] - df["shipping_estimate"] - df["amazon_fees"]
    ).round(2)
    df["margin_pct"] = (
        (df["website_profit"] / df["sell_price"].replace(0, pd.NA)) * 100
    ).fillna(0).round(1)

    profit_component = (df["website_profit"].clip(lower=0, upper=100) / 100) * 55
    margin_component = (df["margin_pct"].clip(lower=0, upper=60) / 60) * 25
    shipping_component = df["shipping_class"].map({
        "Parcel": 20, "Large Parcel": 10, "Freight / Oversize": 0
    }).fillna(0)
    df["opportunity_score"] = (
        profit_component + margin_component + shipping_component
    ).clip(0, 100).round().astype(int)

    return df.sort_values(["opportunity_score", "website_profit"], ascending=False).reset_index(drop=True)

def sample_products() -> pd.DataFrame:
    return pd.DataFrame([
        ["Atlantic Water Gardens", "TIDAL-1500", "727429002311", "TidalWave pond pump 1500 GPH", 74.00, 149.99, 8, 14, 10, 9, 8.50],
        ["Atlantic Water Gardens", "TRION2", "727429010569", "Triton 2 pond skimmer", 229.00, 449.99, 31, 31, 25, 24, 18.00],
        ["Aquascape", "45010", "742575450100", "AquaForce 2700 solids-handling pump", 168.00, 329.99, 12, 16, 12, 11, 10.00],
        ["Aquascape", "96030", "742575960302", "Premium cold water beneficial bacteria", 19.00, 39.99, 2, 8, 5, 5, 5.95],
        ["Anjon", "TRUV55WT", "701160605512", "55 watt UV clarifier with ballast", 124.00, 249.99, 14, 30, 9, 8, 12.00],
        ["EasyPro", "EP2200", "812506011305", "Mag drive pump 2200 GPH", 91.00, 184.99, 9, 15, 11, 10, 8.50],
        ["EasyPro", "FMROLL24", "", "Filter media roll 24 inch x 100 feet", 88.00, 229.99, 42, 48, 24, 24, 45.00],
        ["Matala", "MEAP80", "4712765130285", "Hakko-style linear air pump 80 LPM", 154.00, 299.99, 18, 15, 13, 12, 11.00],
        ["Microbe-Lift", "PLGAL", "097121201309", "PL beneficial bacteria one gallon", 41.00, 79.99, 9, 13, 8, 8, 8.50],
        ["Oase", "45421", "706759454218", "BioPress 1600 pressure filter", 165.00, 329.99, 22, 22, 18, 18, 13.00],
        ["PerformancePro", "C-1/4-44", "", "Cascade external pump 1/4 HP", 410.00, 699.99, 46, 26, 17, 17, 24.00],
        ["Sequence", "11200PWR81", "", "Power series external pump 11200 GPH", 610.00, 999.99, 64, 29, 20, 20, 29.00],
    ], columns=[
        "Vendor", "SKU", "UPC", "Description", "Cost", "MAP",
        "Weight", "Length", "Width", "Height", "Shipping"
    ])
